﻿namespace Nuve.Test.Analysis
{
    internal class VerbDerivationTest
    {
    }
}