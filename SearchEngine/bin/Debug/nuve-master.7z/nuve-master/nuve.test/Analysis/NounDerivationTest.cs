﻿namespace Nuve.Test.Analysis
{
    internal class NounDerivationTest
    {
    }
}