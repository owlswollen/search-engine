﻿namespace Nuve.Distance
{
    public interface IDistance
    {
        double Measure(string s1, string s2);
    }
}