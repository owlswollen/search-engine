﻿using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Nuve.Test")]

namespace Nuve
{
    public class SampleClass
    {

    }
}